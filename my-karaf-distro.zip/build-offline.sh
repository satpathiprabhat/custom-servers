#!/bin/bash
set -e
echo "=== Building all modules ==="
mvn clean install -DskipTests
mvn dependency:go-offline
REPO_DIR="./repo"
mkdir -p $REPO_DIR
mvn dependency:copy-dependencies -DoutputDirectory=$REPO_DIR -DincludeScope=runtime
cd karaf-distribution
echo "=== Packaging Karaf distribution ==="
mvn clean install
echo "=== DONE! Your Karaf distro is in karaf-distribution/target ==="
